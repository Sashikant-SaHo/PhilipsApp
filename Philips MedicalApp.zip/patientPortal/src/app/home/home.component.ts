import {Component, OnInit, ViewChild,Inject} from '@angular/core';
import {MatPaginator, MatTableDataSource} from '@angular/material';
import { Patient } from '../Model/patient';
import { PatientService } from '../service/patient.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { CreateEditComponent } from '../create-edit/create-edit.component';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public displayedColumns:string[];
  public data:Patient[];
  public dataSource;
 
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(public service:PatientService,public dialog: MatDialog) { }

  ngOnInit() {
    this.service.getdata().subscribe(result=>{
      this.data=result as Patient[];
      this.dataSource = new MatTableDataSource<Patient>(this.data);
    })
    
    this.displayedColumns = ['id', 'username', 'age', 'height','weight','email','address','edit','delete'];
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(CreateEditComponent, {
      width: '700px'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
     
    });
  }

}



