import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(public http:HttpClient) { }
  public getdata(){
    return this.http.get('http://localhost:3000/employees');
  }
}
