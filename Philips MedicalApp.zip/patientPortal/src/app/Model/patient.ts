export class Patient {
    id: number;
    username: string;
    age: number;
    height: number;
    weight: 45;
    email: string;
    address: string
}
